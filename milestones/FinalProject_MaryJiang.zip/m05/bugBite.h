#ifndef __BUGBITEH__
#define __BUGBITEH__

#define BUGBITELEN 16239
extern const signed char bugBite[16239];

#endif