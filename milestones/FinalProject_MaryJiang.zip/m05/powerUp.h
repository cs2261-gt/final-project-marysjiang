#ifndef __POWERUPH__
#define __POWERUPH__

#define POWERUPLEN 9702
extern const signed char powerUp[9702];

#endif