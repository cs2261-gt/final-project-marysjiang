#ifndef __BUBBLEGUMKKH__
#define __BUBBLEGUMKKH__

#define BUBBLEGUMKKLEN 1504224
extern const signed char bubblegumKK[1504224];

#endif