#ifndef __KKBOSSAH__
#define __KKBOSSAH__

#define KKBOSSALEN 894528
extern const signed char kkBossa[894528];

#endif