#ifndef __BOSSAKKH__
#define __BOSSAKKH__

#define BOSSAKKLEN 860882
extern const signed char bossaKK[860882];

#endif