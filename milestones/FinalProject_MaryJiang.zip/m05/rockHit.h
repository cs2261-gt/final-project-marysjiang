#ifndef __ROCKHITH__
#define __ROCKHITH__

#define ROCKHITLEN 3729
extern const signed char rockHit[3729];

#endif