#ifndef __RAINYH__
#define __RAINYH__

#define RAINYLEN 1413216
extern const signed char rainy[1413216];

#endif