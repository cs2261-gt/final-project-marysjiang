#ifndef __GOKKRIDERH__
#define __GOKKRIDERH__

#define GOKKRIDERLEN 1770842
extern const signed char goKKRider[1770842];

#endif